import cv2
import numpy as np
from watermarking import embed_watermark, extract_watermark, calculate_metrics
from pywt import dwt2
from utils import add_noise

# Evaluation function (currently using SSIM as fitness)
def evaluate_strength(img, wm, strength):
    cA, _ = dwt2(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), 'haar')
    wm_resized = cv2.resize(wm, (cA.shape[1], cA.shape[0]))

    # Embed
    watermarked = embed_watermark(img, wm_resized, strength)

    # Attack
    attacked = add_noise(watermarked)

    # Extract
    extracted = extract_watermark(img, attacked, strength)

    try:
        _, ssim = calculate_metrics(img, attacked, wm_resized, extracted)
        return -ssim  # Maximize SSIM (minimize negative SSIM)
    except:
        return 1  # Worst case if error occurs

# Basic grid search-based optimizer (could be replaced with full PSO)
def train_strength(img, wm):
    best_strength = 0.1
    best_score = float('inf')

    for strength in np.linspace(0.01, 0.5, 20):  # Try 20 possible values for strength
        score = evaluate_strength(img, wm, strength)
        if score < best_score:
            best_score = score
            best_strength = strength

    return best_strength

# Entry point for testing
if __name__ == "__main__":
    img = cv2.imread("images/lena.png")  # Load in color
    wm = cv2.imread("images/wm.png", 0)  # Watermark as grayscale

    if img is not None and wm is not None:
        optimal_strength = train_strength(img, wm)
        print(f"✅ Optimal Embedding Strength: {optimal_strength:.4f}")
    else:
        print("❌ Host or watermark image not found.")
