import numpy as np
from watermarking import embed_watermark, extract_watermark, calculate_metrics

class Particle:
    def _init_(self, position):
        self.position = position
        self.best_position = position.copy()
        self.velocity = np.zeros_like(position)
        self.best_score = -np.inf

class PSO:
    def _init_(self, objective_func, dim, num_particles=15, max_iter=30):
        self.obj_func = objective_func
        self.num_particles = num_particles
        self.max_iter = max_iter
        self.particles = [Particle(np.random.uniform(0.01, 0.5, dim)) for _ in range(num_particles)]
        self.global_best = self.particles[0].position
        self.global_best_score = -np.inf

    def optimize(self):
        w, c1, c2 = 0.5, 1.5, 1.5
        for _ in range(self.max_iter):
            for particle in self.particles:
                score = self.obj_func(particle.position)
                if score > particle.best_score:
                    particle.best_score = score
                    particle.best_position = particle.position.copy()
                if score > self.global_best_score:
                    self.global_best_score = score
                    self.global_best = particle.position.copy()

            for particle in self.particles:
                r1, r2 = np.random.rand(), np.random.rand()
                particle.velocity = w * particle.velocity + \
                                    c1 * r1 * (particle.best_position - particle.position) + \
                                    c2 * r2 * (self.global_best - particle.position)
                particle.position += particle.velocity
                particle.position = np.clip(particle.position, 0.01, 0.5)
        return self.global_best

def optimize_strength(img, wm, target='NC'):
    def objective_func(pos):
        strength = pos[0]
        try:
            wm_img = embed_watermark(img, wm, strength)
            extracted = extract_watermark(img, wm_img, strength)
            metrics = calculate_metrics(img, wm_img, wm, extracted)
            return metrics.get(target, 0)
        except Exception:
            return -np.inf

    pso = PSO(objective_func, dim=1, num_particles=15, max_iter=30)
    best_strength = pso.optimize()[0]
    return best_strength