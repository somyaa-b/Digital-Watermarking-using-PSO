import cv2
import numpy as np
from skimage.util import random_noise

def add_noise(image, amount=0.02):
    """Add salt & pepper noise."""
    noisy = random_noise(image, mode='s&p', amount=amount)
    return np.uint8(noisy * 255)

def add_blur(image, kernel_size=(5, 5), sigma=1):
    """Apply Gaussian blur."""
    return cv2.GaussianBlur(image, kernel_size, sigma)

def add_compression(image, quality=30):
    """Simulate JPEG compression."""
    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
    result, encimg = cv2.imencode('.jpg', image, encode_param)
    return cv2.imdecode(encimg, 1)

def add_rotation(image, angle=15):
    """Rotate the image."""
    h, w = image.shape[:2]
    M = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1)
    return cv2.warpAffine(image, M, (w, h))

def add_cropping(image):
    """Crop and resize the image to original size."""
    h, w = image.shape[:2]
    cropped = image[h//4:3*h//4, w//4:3*w//4]
    return cv2.resize(cropped, (w, h))