import cv2
import numpy as np

def embed_watermark(image, watermark, alpha=0.1):
    image = cv2.resize(image, (512, 512))
    watermark = cv2.resize(watermark, (512, 512))

    # Convert watermark to grayscale and normalize
    if len(watermark.shape) == 3:
        watermark = cv2.cvtColor(watermark, cv2.COLOR_BGR2GRAY)
    watermark = watermark.astype(np.float32) / 255.0

    # Embed watermark
    watermarked = cv2.addWeighted(image.astype(np.float32), 1, watermark[..., None] * 255, alpha, 0)
    return watermarked.astype(np.uint8)

def extract_watermark(original, watermarked, alpha=0.1):
    original = cv2.resize(original, (512, 512)).astype(np.float32)
    watermarked = cv2.resize(watermarked, (512, 512)).astype(np.float32)

    # Extract watermark approximation
    extracted = (watermarked - original) / alpha
    extracted = np.clip(extracted, 0, 255)
    return extracted.astype(np.uint8)

def calculate_metrics(original, watermarked, watermark, extracted):
    from skimage.metrics import peak_signal_noise_ratio as psnr
    from skimage.metrics import structural_similarity as ssim

    original = cv2.resize(original, (512, 512))
    watermarked = cv2.resize(watermarked, (512, 512))
    watermark = cv2.resize(watermark, (512, 512))
    extracted = cv2.resize(extracted, (512, 512))

    if len(original.shape) == 3:
        original_gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
        watermarked_gray = cv2.cvtColor(watermarked, cv2.COLOR_BGR2GRAY)
    else:
        original_gray = original
        watermarked_gray = watermarked

    psnr_value = psnr(original_gray, watermarked_gray)
    ssim_value = ssim(original_gray, watermarked_gray)

    return psnr_value, ssim_value
