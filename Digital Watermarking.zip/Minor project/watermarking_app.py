import streamlit as st
import cv2
import numpy as np
import os
from watermarking import embed_watermark, extract_watermark, calculate_metrics
from pso import optimize_strength
from utils import add_noise, add_blur, add_compression, add_rotation, add_cropping
from pywt import dwt2

st.markdown("## Digital Watermarking with PSO + Robustness")

# Upload images
with st.expander("Upload Images", expanded=True):
    uploaded_img = st.file_uploader("Upload Host Image", type=["png", "jpg", "jpeg"])
    uploaded_wm = st.file_uploader("Upload Watermark Image", type=["png", "jpg", "jpeg"])

img, wm = None, None

if uploaded_img:
    img_path = os.path.join("images", uploaded_img.name)
    with open(img_path, "wb") as f:
        f.write(uploaded_img.read())
    st.success(f"Host image saved to {img_path}")
    img = cv2.imread(img_path, 0)

if uploaded_wm:
    wm_path = os.path.join("images", uploaded_wm.name)
    with open(wm_path, "wb") as f:
        f.write(uploaded_wm.read())
    st.success(f"Watermark image saved to {wm_path}")
    wm = cv2.imread(wm_path, 0)

if img is not None and wm is not None:
    col1, col2 = st.columns(2)
    with col1:
        st.image(img, caption="Host Image", width=250)
    with col2:
        st.image(wm, caption="Watermark", width=250)

    use_pso = st.checkbox("Use PSO to Optimize Strength", value=True)
    strength = optimize_strength(img, wm) if use_pso else st.slider("Set Embedding Strength", 0.01, 0.5, 0.1)

    cA, _ = dwt2(img, 'haar')
    wm_resized = cv2.resize(wm, (cA.shape[1], cA.shape[0]))

    with st.spinner(" Embedding watermark..."):
        watermarked = embed_watermark(img, wm_resized, strength=strength)
    st.image(watermarked, caption="Watermarked Image", width=300)

    # Attacks
    st.markdown("###  Apply Robustness Attacks")
    selected_attacks = st.multiselect("Select Attacks", ["Noise", "Blur", "Compression", "Rotation", "Cropping"])

    attacked = watermarked.copy()
    if "Noise" in selected_attacks:
        attacked = add_noise(attacked)
    if "Blur" in selected_attacks:
        attacked = add_blur(attacked)
    if "Compression" in selected_attacks:
        attacked = add_compression(attacked)
    if "Rotation" in selected_attacks:
        attacked = add_rotation(attacked)
    if "Cropping" in selected_attacks:
        attacked = add_cropping(attacked)

    st.image(attacked, caption="Attacked Watermarked Image", width=300)

    attacked_resized = cv2.resize(attacked, (img.shape[1], img.shape[0]))
    if len(attacked_resized.shape) == 3:
        attacked_resized = cv2.cvtColor(attacked_resized, cv2.COLOR_BGR2GRAY)

    with st.spinner("Extracting watermark..."):
        extracted = extract_watermark(img, attacked_resized, strength=strength)

    extracted_resized = cv2.resize(extracted, (wm.shape[1], wm.shape[0]))
    st.image(extracted_resized, caption="Extracted Watermark", width=250)

    # Metrics
    st.markdown("###  Evaluation Metrics")
    try:
        metrics = calculate_metrics(img, attacked_resized, wm, extracted_resized)
        st.write(f"*PSNR:* {metrics['PSNR']:.2f}")
        st.write(f"*SSIM:* {metrics['SSIM']:.4f}")
        st.write(f"*NC (Normalized Correlation):* {metrics['NC']:.4f}")
    except ValueError as ve:
        st.error(f"Metric Calculation Error: {ve}")